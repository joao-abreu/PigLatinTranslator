exports.test = function(testeVar){
    testeVar = "teste ok...";
}


exports.translateToPigLatin = function(text){
    // Create variables to be used
    var pigLatin = '';
    var regex = /[aeiou]/gi;

    // Check if the first character is a vowel
    if (text[0].match(regex)) {
        pigLatin = text + 'way';

    } else {

        // Find how many consonants before the first vowel.
        var pos = text.indexOf(text.match(regex)[0]);

        // Take the string from the first vowel to the last char
        // then add the consonants that were previously omitted and add the ending.
        pigLatin = text.substr(pos) + text.substr(0, pos) + 'ay';
    }

    return pigLatin;
}

/**
 * Generates a random string
 * @param length
 * @returns {string}
 */
exports.generateUUID = function(length){
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    if(!length) length = 10;

    for( var i=0; i < length; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}