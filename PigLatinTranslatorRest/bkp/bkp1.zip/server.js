var express		=	require('express');
var session		=	require('express-session');
var bodyParser  = 	require('body-parser');
var app			=	express();
var path 		= 	require('path');
var mailer = require('mailer');
var process 	= 	require('./routes/process.js');

app.set('views', __dirname + '/views');
app.engine('html', require('ejs').renderFile);

app.use(session({secret: 'JHFAStasaytYR45&%&asfa',saveUninitialized: true,resave: false}));
app.use(bodyParser.json());      
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static(path.join(__dirname, 'public')));



var sess;
const IS_DEV = true;
var users = [{name:"Joao Abreu", email: "joao", password: "MTIz"}]; // save the active users in memory
var tmpUsers = []; // save the temporary users in memory
var translations = []; //Save the history of translations
var recoverPassUsers = [];


//test
var t = "nok test";
console.log(t);
process.test(t);
console.log(t);


/////////


//Redirects
app.get('/home',function(req,res){
	res.render('home.html');
});
app.get('/myAccount',function(req,res){
    res.render('myAccount.html');
});
app.get('/',function(req,res){
	res.render('home.html');
});
////

/**
 * Initializes the password rcovery process
 */
app.post('/recoverPassword', function(req, res) {

    //get email
    var email = req.body.email;
   // /^[0-9]+$/.test("123")
    getUserByEmail(email, function(user){
        if (user) {
            var name = user.name;
            //generates an uuid
            var uuid = process.generateUUID(10);

            //Process the email
            var confirmationLink = 'http://localhost:3000/recoverConfirmation?uuid=' + uuid;

            var emailTo = email;
            if (IS_DEV) {
                emailTo = "joaoabreu.wd@gmail.com";
            }

            var template = "./emailTemplates/emailRecoverPasswordTpl.txt";
            processEmail(emailTo, name, confirmationLink, template, function (success) {
                if (success) {
                    console.log("Email de recuperação enviado");

                    //Saves the data to the recoveryPassUsers array to be used later
                    var obj = {
                        email: email,
                        uuid: uuid
                    }
                    recoverPassUsers.push(obj);

                    //process the success response
                    var json = {message: "Recuperação enviada para o email."};
                    processSuccessResponse(res, json);
                }
                else {
                    console.log("Erro ao enviar Email de recuperação!");
                    var json = {message: "Ocorreu um erro ao enviar o email. Por favor tente novamente mais tarde."};
                    processFailResponse(res, json);
                }
            });

        }
        else {
            var json = {message: "Account dont exists!"};
            console.log("recoverPass: conta não existe!!");
            processFailResponse(res, json);
        }
    });

});

/**
 * Processes the password recover
 */
app.get('/recoverConfirmation', function(req, res){
    var receivedUUID = req.query.uuid;
    console.log("Received uuid: " + receivedUUID);

    //verifies the received uuid
    verifyPasswordRecoveryByUUID(receivedUUID, function(recoverOjb){
        if(recoverOjb){
            var email = recoverOjb.email;

            getUserByEmail(email, function(user){
                //Sets the user in session
                sess=req.session;
                sess.sessdata = {};
                sess.sessdata.email= user.email;
                sess.sessdata.name= user.name;

                res.render('myAccount.html');
            })
        }
    });
});

function verifyPasswordRecoveryByUUID(uuid, cb){
    var recoverOjb = null;
    for(var i=0; i<recoverPassUsers.length; i++){
        if(recoverPassUsers[i].uuid == uuid){
            recoverOjb = recoverPassUsers[i];
        }
    }
    if(cb) cb(recoverOjb);
}

function getUserByEmail(email, cb){
    var user = null;

    for(var i=0; i<users.length; i++){
        if( email == users[i].email){
            user = users[i];
        }
    }
    if(cb) cb(user);
}

app.post('/update', function(req, res){
    console.log("Update account...");

    if(sess && sess.sessdata && sess.sessdata.email){
        var name = req.body.name;
        var password = req.body.password;


        var email = sess.sessdata.email;
        //update the data to this user
        console.log("OK update user");
        console.log(email);

        updateUser(email, name, password, function(updated){

            if(updated){
                console.log("Utilizar actualizado...");
                processSuccessResponse(res);
            }
            else{
                console.log("Erro ao actualizar o utilizador...");
                var json = {message: "Erro ao actualizar o utilizador..."};
                processFailResponse(res, json)
            }
        });
    }
    else{
        console.log("Erro no update, sem email na sessão...");
        var json = {message: "Não autorizado", code: 401};
        processFailResponse(res, json)
    }


})

function updateUser(email, name, password, cb){
    var updated = false;

    for(var i=0; i<users.length; i++){
        if( email == users[i].email){
            users[i].name = name;
            users[i].password = new Buffer(password).toString('base64');
            sess.sessdata.name = name;

            updated = true;
        }
    }

    if(cb) cb(updated);
}
app.post('/register', function(req, res){
	var email = req.body.email;

    verifyExistingAccount(email, function(exists){

        if(exists){
            var json = {message: "Already registered!"};
            console.log("Email já registado!!");
            processFailResponse(res, json);
        }
        else{
            console.log("Email ainda não registado...");
            var password = req.body.password;
            var name = req.body.name;
            var uuid = process.generateUUID(10);

            console.log("UUID esperado:  "+ uuid);
            console.log("email:  "+ email);
            console.log("name:  "+ name);



            //Process the email
            var confirmationLink = 'http://localhost:3000/registerConfirmation?uuid='+uuid;

            var emailTo = email;
            if(IS_DEV){
                emailTo = "joaoabreu.wd@gmail.com";
            }

            var template = "./emailTemplates/emailConfirmationTpl.txt";
            processEmail( emailTo, name, confirmationLink, template, function(success){
                if(success){
                    console.log("Email de confirmação enviado");
                    //Saves the new user
                    tmpUsers.push({name: name, email: email, password: new Buffer(password).toString('base64'), uuid: uuid, registeredAt: new Date().getTime() });

                    //process the success response
                    var json = {message: "Confirmação enviada para o email."};
                    processSuccessResponse(res, json);
                }
                else {
                    console.log("Erro ao enviar Email de confirmação!");
                    var json = {message: "Ocorreu um erro ao enviar o email. Por favor tente novamente mais tarde."};
                    processFailResponse(res, json);
                }
            });
        }
    })
});

app.get('/registerConfirmation', function(req, res){
	var receivedUUID = req.query.uuid;

	console.log("Received uuid: " + receivedUUID);

	verifyTempUser(receivedUUID, function(user){

		if(user){
			console.log("Registo validado para o user:");
			console.log(user);
            //Sets the user in the user database (memory)
			users.push(user);

            //Sets the user in session
            sess=req.session;
            sess.sessdata = {};
            sess.sessdata.email= user.email;
            sess.sessdata.name= user.name;

            res.render('home.html');
		}
		else{
			console.log("Registo não validado!!Confirma email");

			//var json = {message: "Pre Registo inválido"};
			//processFailResponse(res, json);
            res.render('home.html');
		}
	});
});

//app.post('/login', process.login);
app.post('/login', function(req, res){
	//process.login(req, res, sess);
	var email = req.body.email;
	var password = req.body.password;

	verifyUserLogin(email, password, function(user){
		if(user){
			console.log("Login OK");
            console.log("Session User");
            console.log(user);
			sess=req.session;
			sess.sessdata = {};
			sess.sessdata.email= email;
            sess.sessdata.name= user.name;

			var json = {message: "Login OK", user: user};
			processSuccessResponse(res, json);
		}
		else{
			console.log("Login invalido");
			var json = {message: "Login inválido", code: 401};
			processFailResponse(res, json);
		}
	});



});

app.post('/verifyUserSession',function(req,res){
	if(sess && sess.sessdata) console.log(sess.sessdata);

	if(verifyUserSession()){
		console.log("User in session");
		console.log(sess.sessdata.email);

        var json = {user: sess.sessdata};
        processSuccessResponse(res, json);
	}
	else {
		console.log("No user in session");
        var json = {user: null};
        processFailResponse(res, json);
	}
});

app.get('/logout', function(req, res){
    console.log("Logout...");
    sess = null;

    processSuccessResponse(res);
});


app.post('/translate', function(req, res) {
    if(verifyUserSession()){
        var text = req.body.text;

        if(text){
            console.log("Texto a traduzir:");
            console.log(text);

            var translated = process.translateToPigLatin(text);

            console.log("Texto traduzido:");
            console.log(translated);

            translations.push( {text: text, translated: translated} );

            var json = {message: "OK", text: translated};
            processSuccessResponse(res, json);
        }
        else{
            var json = {message: "Texto obrigatório"};
            processFailResponse(res, json);
        }

    }
    else{
        console.log("Login obrigatorio para traduzir:");
        var json = {message: "Login obrigatório", code: 401};
        processFailResponse(res, json);
    }

});

app.get('/history', function(req, res){
    var json = {message: "Pig Latin Translations", translations: translations};
    processSuccessResponse(res, json);
});

app.listen(3000,function(){
	console.log("App Started on PORT 3000");
});

/**
 * Process the email to be sent
 * @param emailTo
 * @param name
 * @param confirmationLink
 * @param template (file path)
 * @param cb
 */
function processEmail(emailTo, name, confirmationLink, template, cb){


    mailer.send({
        host : "smtp.gmail.com",              // smtp server hostname
        port : "587",                     // smtp server port
        domain : "localhost",            // domain used by client to identify itself to server
        to : emailTo,
        from : "dev.joaoabreu.wd@gmail.com",
        subject : "Confirmação de conta",
        //body: emailBody,
        template: template,
        data : {
            "name": name,
            "confirmationLink": confirmationLink,
        },
        authentication : "login",        // auth login is supported; anything else is no auth
        username : "dev.joaoabreu.wd@gmail.com",       // Base64 encoded username
        password : "Dev123456789"        // Base64 encoded password
    },
    function(err, result){
        console.log("result");
        console.log(result);
        if(cb){
            console.log("Callback");
            cb(result);
        }
        if(err){
            console.log(err);
            success = false;
        }
        //if(cb) cb(success);
    });
}


/**
 * Verifies the user in session
 * @returns {boolean}
 */
function verifyUserSession(){
	if(sess && sess.sessdata && sess.sessdata.email){
		return true;
	}
	else {
		return false;
	}
}

/**
 * Verifies the user login by the given email and password
 * @param email
 * @param password
 * @param cb
 */
function verifyUserLogin(email, password, cb){
    var pass64 = new Buffer(password).toString('base64');

	var user = null;
	for(var i=0; i<users.length; i++){
		if( email == users[i].email && pass64 == users[i].password ){
			user = users[i];
		}
	}
	if(cb) cb ( user );
}

/**
 * Verifies if the account already exists
 * @param email
 * @param cb
 */
function verifyExistingAccount(email, cb){
    var exists = false;

    //Registered users
    for(var i=0; i<users.length; i++){
        if( email == users[i].email){
            exists = true;
        }
    }

    //Removes the older users from the tmpUsers registry
    removeOlderTmpUsers(function(){
        //Users waiting for confirmation users
        for(var i=0; i<tmpUsers.length; i++){
            if( email == tmpUsers[i].email){
                exists = true;
            }
        }
    });

    if(cb) cb ( exists );
}

/**
 * Removes the users that submit the registry more than 24 hours ago
 * @param cb
 */
function removeOlderTmpUsers(cb){
    for(var i=0; i<tmpUsers.length; i++){
        var timeMillis = 1000*60*60*24;
        if( new Date().getTime() > tmpUsers[i].registeredAt + timeMillis){
            tmpUsers.splice(i, 1); //removes the object from the array
        }
    }
    if(cb) cb();
}

/**
 * Search the temporary register for a user by the given UUID
 * @param uuid
 * @param cb
 */
function verifyTempUser(uuid, cb){
	var user = null;

	for(var i=0; i < tmpUsers.length; i++){
		console.log(tmpUsers[i]);
		if(tmpUsers[i].uuid == uuid){
			user = tmpUsers[i];
			tmpUsers.splice(i, 1); //removes the object from the array
		}
	}

	if(cb) cb( user );
}

/**
 * Process a generic success response to client
 * @param res
 * @param json
 */
function processSuccessResponse(res, json){
	if(!json) json = {};
	json.success = true;
	res.send( JSON.stringify(json) );
}

/**
 * Process a generic fail response to client
 * @param res
 * @param json
 */
function processFailResponse(res, json){
	if(!json) json = {};
	json.success = false;
    res.send( JSON.stringify(json) );
}

/**
 * Translates the given text to Pig Latin
 * @param text
 * @returns {string}
 */
function translateToPigLatin2(text){
    console.log("The text to translate:");
    console.log(text);
    var words = text.split(" ");
    var formatedText = "";

    for(var i=0; i<words.length; i++){
        var appendWAY = false;
        //var moveFirstLetter = false;
        var word = words[i];
        console.log("The word to check");
        console.log(word);

        var letters = word.split("");
        var formatedWord = "";
        var once = true;
        var movedWord = "";
        for(var j=0; j<letters.length; j++){
            var letter = letters[j].toUpperCase();

            //Words that start with a vowel (A, E, I, O, U) simply have "WAY" appended to the end of the word.
            if(letter == "A" || letter == "E" || letter == "I" || letter == "U"){
                appendWAY = true;
            }


            //TODO
            //Words that start with a consonant have all consonant letters up to the first vowel moved to the
            // end of the word (as opposed to just the first consonant letter), and "AY" is appended.
            // ('Y' is counted as a vowel in this context)
            if(once){
                var lett = letters[0].toUpperCase();
                if(lett != "A" || lett != "E" || lett != "I" || lett != "U" || lett != "Y"){
                    var firstPart = "";
                    var seccondPart = "";
                    var keepMoving = true;
                    for(var k=0; k<letters.length; k++){

                        var l = letters[k].toUpperCase();
                        if(l == "A" || l == "E" || l == "I" || l == "U" || l == "Y"){
                            keepMoving = false;
                        }

                        if(keepMoving){
                            seccondPart += letters[k];
                        }
                        else{
                            firstPart += letters[k];
                        }





                        movedWord = firstPart + seccondPart;
                    }

                    word =  movedWord;
                    once = false;
               }

            }
        }


        //Apply conditions
        if(appendWAY){
            formatedWord = word + "WAY";
        }
        else{
            formatedWord = word;
        }

        //Build the sentence again
        if(i<words.length-1){
            formatedText += formatedWord + " ";
        }
        else{
            formatedText += formatedWord;
        }

    }

    return formatedText;//text.toUpperCase();
}

exports.lower = function(text){
    return text.toLowerCase();
}