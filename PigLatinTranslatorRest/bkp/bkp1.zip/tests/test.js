var chai = require('chai');
var expect = require('chai').expect;
var run = require('../routes/process.js');



describe('translateToPigLatin', function(){

    it('Pig Latin Translator', function(){
        var word = "ventureaok";
        var testWord = run.translateToPigLatin(word);
        console.log(testWord);
        expect( testWord ).to.equal('entureaokvay');


        /*expect( testWord ).to.not.equal('hello earth');
        expect( testWord ).to.be.a('string');
        expect( testWord ).to.not.be.a('number');
        expect( obj ).to.have.property('success').with.lengthOf(3);
        expect( testWord ).to.contain('hello');*/
    })

    it('generateUUID', function(){
        var size = 10;
        var uuid = run.generateUUID( size );
        console.log(uuid);
        expect( uuid ).to.be.a('string');
        expect( uuid ).to.have.lengthOf( size );
    })
});